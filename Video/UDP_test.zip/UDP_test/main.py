from Test_server import *
import threading
import argparse
import time




parser = argparse.ArgumentParser()
parser.add_argument('--host', type=str, default='192.168.3.96')
parser.add_argument('--port', type=int, default=80)
args = parser.parse_args()


IP = args.host
PORT = args.port
if __name__=='__main__':
    vclient=VideoServer(PORT)
    vclient.start()
    time.sleep(1)
    while True:
        time.sleep(1)
