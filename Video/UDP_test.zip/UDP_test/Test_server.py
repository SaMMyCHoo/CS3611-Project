import socket
import queue
import cv2
import numpy as np
import threading
import time
# # 创建一个 UDP socket
# server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# # 设置套接字的接收缓冲区大小为 65535 字节
# server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65535)
# # 设置套接字的发送缓冲区大小为 65535 字节
# server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65535)
# # 绑定要监听的端口
# # server_address = ('',80)
# server_address = ('192.168.3.238',80)
# server_socket.bind(server_address)


class VideoServer(threading.Thread):
    def __init__(self,port):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.address = ("" ,port)
        # 创建一个 UDP socket
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 设置套接字的接收缓冲区大小为 65535 字节
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65535)
        # 设置套接字的发送缓冲区大小为 65535 字节
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65535)
        # 客户端信息列表
        self.clients = {}
        self.frame_queue=queue.Queue()
    def handle_client(self):
        # """
        # 处理客户端连接
        # """
        # # frame_data = []
        # # data_seq = []
        # while True:
        #     # 接收数据
        #     data, client_address = self.server_socket.recvfrom(4104)
        #     if client_address not in self.clients:
        #         frame_queue=queue.Queue()
        #         self.clients[client_address]=frame_queue
        #     for cl in self.clients:
        #         if cl != client_address:
        #             self.server_socket.sendto(data,cl)
        while True:
            try:
                # 接收数
                data ,server_address= self.server_socket.recvfrom(4104)
                print("heoods")
                # print("接收到来自服务器端{}的视频:".format(server_address))
                # 解析 UDP 分片
                seq_num = int.from_bytes(data[:4], byteorder='big')
                checksum1 = int.from_bytes(data[4:8], byteorder='big')
                payload = data[8:]
                # 验证校验和
                if (checksum1 == sum(payload) & 0xffffffff)  :
                    if seq_num == self.count:
                        # 处理完整的视频帧
                        peices_frame=payload
                        self.frame+=peices_frame
                        self.count+=1
                    else:
                        self.frame_queue.put(self.frame)
                        print("获取的帧数后的图片池：",self.frame_queue.qsize())
                        self.frame=payload
                        self.count=1
                else:
                    print('分片校验和错误')
                    continue
            except Exception as e:
                # print("Receivving Error is :",e)
                continue
    def show_video(self):
        # cv2.namedWindow("Remote Camera", cv2.WINDOW_NORMAL)  # 创建窗口
        while True:
            try:
                data=self.frame_queue.get()
                print("取出后的图片池:",self.frame_queue.qsize())
                # time.sleep(0.01)
                # print("从视频池子中取出后的帧数：",frame_queue.qsize())
                frame = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
                # cv2.imwrite("C:\\Users\\32860\\Desktop\\image\\{}.png".format(self.k),frame)
                # self.k+=1
                # if self.k>100:
                #     break
                cv2.imshow("Remote Camera",frame)
                k=cv2.waitKey(5)
                if k==27:
                    break
            except Exception as e:
                print("receiving error : ",e)
                continue
        cv2.destroyAllWindows()
    def run(self):
        t=threading.Thread(target=self.handle_client,daemon=True).start()
        t1=threading.Thread(target=self.show_video,daemon=True).start()