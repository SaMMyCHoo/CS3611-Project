import cv2
import socket
import time
import threading
import queue
import numpy as np



class VideoClient(threading.Thread):
    def __init__(self,IP,PORT):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        # 定义服务器地址和端口号
        self.server_address = (IP,PORT)
        self.cap=cv2.VideoCapture(0)
        # 创建一个 UDP socket
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 设置套接字的接收缓冲区大小为 65535 字节
        self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65535)
        # 设置套接字的发送缓冲区大小为 65535 字节
        self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65535)
        self.frame_queue=queue.Queue()
        self.count=0
        self.frame=b''

    def send_frame(self):
        while True:
            ret, frame = self.cap.read()
            time.sleep(0.1)
            ret, buffer = cv2.imencode('.jpg', frame)
            jpeg_frame = buffer.tobytes()
            # 分片序号
            seq_num = 0
            # 循环分片并发送
            for i in range(0, len(jpeg_frame), 4*1024):
                # 构建 UDP 分片
                chunk = jpeg_frame[i:i+4*1024]
                checksum1 = sum(chunk) & 0xffffffff
                udp_packet = seq_num.to_bytes(4, byteorder='big') + \
                            checksum1.to_bytes(4, byteorder='big') +chunk
                # 发送 UDP 分片
                self.client_socket.sendto(udp_packet, self.server_address)
                self.client_socket.sendto(udp_packet, self.server_address)
                # 分片序号递增
                seq_num += 1
        # 关闭 socket
        print("断开连接。。。。。")
        client_socket.close()
    
    def receive_frame(self):
        while True:
            try:
                # 接收数
                data ,server_address= self.client_socket.recvfrom(4104)
                # print("接收到来自服务器端{}的视频:".format(server_address))
                # 解析 UDP 分片
                seq_num = int.from_bytes(data[:4], byteorder='big')
                checksum1 = int.from_bytes(data[4:8], byteorder='big')
                payload = data[8:]
                # 验证校验和
                if (checksum1 == sum(payload) & 0xffffffff)  :
                    if seq_num == self.count:
                        # 处理完整的视频帧
                        peices_frame=payload
                        self.frame+=peices_frame
                        self.count+=1
                    else:
                        self.frame_queue.put(self.frame)
                        print("获取的帧数后的图片池：",self.frame_queue.qsize())
                        self.frame=payload
                        self.count=1
                else:
                    print('分片校验和错误')
                    continue
            except Exception as e:
                # print("Receivving Error is :",e)
                continue
    def show_video(self):
        # cv2.namedWindow("Remote Camera", cv2.WINDOW_NORMAL)  # 创建窗口
        while True:
            try:
                data=self.frame_queue.get()
                print("取出后的图片池:",self.frame_queue.qsize())
                # time.sleep(0.01)
                # print("从视频池子中取出后的帧数：",frame_queue.qsize())
                frame = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
                # cv2.imwrite("C:\\Users\\32860\\Desktop\\image\\{}.png".format(self.k),frame)
                # self.k+=1
                # if self.k>100:
                #     break
                cv2.imshow("Remote Camera",frame)
                k=cv2.waitKey(5)
                if k==27:
                    break
            except Exception as e:
                print("receiving error : ",e)
                continue
        cv2.destroyAllWindows()

    def run(self):
        send=threading.Thread(target=self.send_frame,daemon=True).start()
        receive=threading.Thread(target=self.receive_frame,daemon=True).start()
        show=threading.Thread(target=self.show_video,daemon=True).start()




