import socket
import threading
import cv2
import numpy as np
import time
import queue
import struct

class VideoChatServer(threading.Thread):
    def __init__(self, port):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.address = ("" ,port)
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.clients = []
        self.is_running = False
        self.dict_queue={}
    def start(self):
        # 创建 TCP 套接字并绑定到地址和端口号
        self.server_socket.bind(self.address)
        # 监听客户端连接
        self.server_socket.listen()
        print("Server started on {}:{}".format(*self.address))

        self.is_running = True
        while self.is_running:
            # 接受客户端连接
            client_socket, client_address = self.server_socket.accept()
            if client_socket not in self.clients:
                self.clients.append([client_socket,client_address])
                frame_queue=queue.Queue()
                self.dict_queue[client_socket]=frame_queue
                print("{} Successfully connected!!".format(client_address))
            # 处理客户端消息
            t=threading.Thread(target=self.handle_client, args=(client_socket, client_address))
            t.daemon=True
            t.start()

    def stop(self):
        self.is_running = False
        if self.server_socket:
            self.server_socket.close()
        for client_socket in self.clients:
            client_socket[0].close()
        self.clients.clear()

    def receive_frame(self, client_socket, address):
        print(f"New connection from {address}")
        while True:
            # 接收客户端发送的视频帧
            try:
                header = client_socket.recv(4)
                length, = struct.unpack("!I", header)
                data = b""
                while len(data)<length:
                    packet = client_socket.recv(min(4096,length - len(data)))
                    if not packet:
                        break
                    data += packet
                frame_data=data[:length]
                length=len(frame_data)
                header=struct.pack("!I",length)
                self.dict_queue[client_socket].put(header+frame_data)
                # time.sleep(0.5)
            except Exception as e:
                print("Vedio frame cannot receive,Error is: ",e)
                break
        client_socket.close()
        self.clients.remove([client_socket,address])
        print(f"Connection closed from {address}")
    def transmit_frame(self,client_socket):
        while True:
            try:
                data=self.dict_queue[client_socket].get()
                for i in self.clients:
                    if i[0]!=client_socket:
                        i[0].sendall(data)
            except Exception as e:
                print("Transmit Error is :",e)
                continue
    def handle_client(self,client_socket,addrr):
        threading.Thread(target=self.receive_frame,args=(client_socket,addrr),daemon=True).start()
        threading.Thread(target=self.transmit_frame,args=((client_socket,)),daemon=True).start()

class VideoChatClient(threading.Thread):
    def __init__(self, host=None, port=None):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.host = host
        self.port = port
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.capture = cv2.VideoCapture(0)
    
    def run(self):
        # 创建 TCP 套接字并连接到服务器
        print("VIDEO client starts...")
        while True:
            try:
                address = (self.host, self.port)
                self.client_socket.connect(address)
                break
            except Exception as e:
                time.sleep(3)
                print("Error is : ",e)
                continue
        print("Connected to server.....")
        t1=threading.Thread(target=self.receive_video_frame)
        t1.daemon=True
        t1.start()
        t2=threading.Thread(target=self.send_video_frame)
        t2.daemon=True
        t2.start()

    def disconnect(self):
        # 关闭套接字
        if self.client_socket:
            self.client_socket.close()

    def send_video_frame(self, frame):
        # 将视频帧编码成 JPEG 格式并添加结束标志
        while True:
            try:
                ret, frame = self.capture.read()
                if not ret:
                    return None
                ret, buffer = cv2.imencode('.jpg', frame)
                jpeg_frame = buffer.tobytes() + b"EOF"
                self.client_socket.sendall(jpeg_frame)
            except Exception as e:
                print("Send_frame error occur: ",e)
                continue

    def receive_video_frame(self):
        # 接收并返回来自服务器转发的视频帧
        data = b""
        while True:
            packet = self.client_socket.recv(1024)
            if packet.endswith(b"EOF"):
                data += packet[:-3]
                break
            data += packet
        frame = np.frombuffer(data, dtype=np.uint8)
        frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
        cv2.imshow("Remote screen",frame)
        if cv2.waitKey(1)==27:
            return
