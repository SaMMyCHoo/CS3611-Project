from video import *
import time
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--host', type=str, default='47.120.39.175')
parser.add_argument('--port', type=int, default=137)
args = parser.parse_args()
IP = args.host
PORT = args.port


if __name__=="__main__":
    # vserver=threading.Thread(target=VideoChatServer,args=("172.20.100.199",137))
    # vclient_1=threading.Thread(target=VideoChatClient,args=("47.120.39.175",137))
    vclient_1=VideoChatClient(IP,PORT)
    # vclient_2=threading.Thread(target=VideoChatClient,args=("47.120.39.175",137))
    time.sleep(1)
    vclient_1.start()
    while True:
        time.sleep(1)
