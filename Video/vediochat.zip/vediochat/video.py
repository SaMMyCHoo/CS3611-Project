from socket import *
import threading
import cv2
import numpy as np
import time
import queue
import struct


class VideoChatServer(threading.Thread):
    def __init__(self, host=None, port=None):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.host = host
        self.port = port
        self.server_socket = None
        self.clients = []
        self.is_running = False
    
    def start(self):
        # 创建 TCP 套接字并绑定到地址和端口号
        self.server_socket = socket(AF_INET, SOCK_STREAM)
        address = (self.host, self.port)
        self.server_socket.bind(address)

        # 监听客户端连接
        self.server_socket.listen()
        print("Server started on {}:{}".format(*address))

        self.is_running = True
        while self.is_running:
            # 接受客户端连接
            client_socket, client_address = self.server_socket.accept()
            if client_socket not in self.clients:
                self.clients.append([client_socket,client_address])
            # 处理客户端消息
            t=threading.Thread(target=self.handle_client, args=(client_socket, client_address))
            t.daemon=True
            t.start()

    def stop(self):
        self.is_running = False
        if self.server_socket:
            self.server_socket.close()
        for client_socket in self.clients:
            client_socket[0].close()
        self.clients.clear()

    def handle_client(self, client_socket, address):
        print(f"New connection from {address}")
        while True:
            # 接收客户端发送的视频帧
            try:
                data = b""
                while True:
                    packet = client_socket.recv(1024)
                    if packet.endswith(b"EOF"):
                        data += packet[:-3]
                        break
                    data += packet
                frame = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
            except:
                break
            print(f"Received video frame from {address}")

            # 广播消息给所有客户端
            for client in self.clients:
                if client != [client_socket,address]:
                    # 将视频帧编码成 JPEG 格式并添加结束标志
                    ret, buffer = cv2.imencode('.jpg', frame)
                    jpeg_frame = buffer.tobytes() + b"EOF"
                    client[0].send(jpeg_frame)

        client_socket.close()
        self.clients.remove([client_socket,address])
        print(f"Connection closed from {address}")



class VideoChatClient(threading.Thread):
    def __init__(self, ip, port):
        threading.Thread.__init__(self)
        self.setDaemon(True)
        self.ADDR=(ip,port)
        self.client_socket = socket(AF_INET, SOCK_STREAM)
        self.capture = cv2.VideoCapture(0)
        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.frame_queue=queue.Queue()
    
    def start(self):
        # 创建 TCP 套接字并连接到服务器
        print("VIDEO client starts...")
        while True:
            try:
                self.client_socket.connect(self.ADDR)
                break
            except Exception as e:
                time.sleep(3)
                print("Error is : ",e)
                continue
        print("Connected to server.....")
        t=threading.Thread(target=self.receive,daemon=True)
        t.start()
        t2=threading.Thread(target=self.send_video_frame,daemon=True)
        t2.start()

    def disconnect(self):
        # 关闭套接字
        if self.client_socket:
            self.client_socket.close()

    def send_video_frame(self):
        # 将视频帧编码成 JPEG 格式并添加结束标志
        # 创建FFmpeg进程并设置参数
        while self.capture.isOpened():
            try:
                ret, frame = self.capture.read()
                time.sleep(0.1)  # 时延保证稳定性
                ret, buffer = cv2.imencode('.jpg', frame)
                # jpeg_frame = buffer.tobytes() + b"EOF"
                jpeg_frame = buffer.tobytes()
                length=len(jpeg_frame)
                header=struct.pack("!I",length)
                self.client_socket.sendall(header+jpeg_frame)
            except Exception as e:
                print("Send_frame error occur: ",e)
                continue
    
    def show_video(self):
        # cv2.namedWindow("Remote Camera", cv2.WINDOW_NORMAL)  # 创建窗口
        while True:
            try:
                data=self.frame_queue.get()
                frame = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
                cv2.imshow("Remote Camera",frame)
                k=cv2.waitKey(5)
                if k==27:
                    break
            except Exception as e:
                print("receiving error : ",e)
                continue
        cv2.destroyAllWindows()
                

    def receive_video_frame(self):
        while True:
            try:
                header = self.client_socket.recv(4)
                length, = struct.unpack("!I", header)
                # 接收帧内容并解码为图片
                data = b""
                while len(data) < length:
                    packet = self.client_socket.recv(min(4096,length - len(data)))
                    if not packet:
                        break
                    data += packet
                frame_data = data[:length]
                self.frame_queue.put(frame_data)
            except Exception as e:
                print("receiving error : ",e)
                break
        self.client_socket.close()
        print("与服务器断开连接")
    
    def receive(self):
        # create show video thread
        threading.Thread(target=self.show_video, daemon=True).start()
        # create receive video thread
        threading.Thread(target=self.receive_video_frame, daemon=True).start()
        

